import React, { useState } from "react";

const Requests = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    name: "",
    documentType: "barangay-clearance",
    purpose: "",
    contact: "",
  });

  const documentTypes = [
    { value: "barangay-clearance", label: "Barangay Clearance" },
    { value: "business-permit", label: "Business Permit" },
    { value: "certificate-of-indigency", label: "Certificate of Indigency" },
    { value: "barangay-id", label: "Barangay ID" },
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requestData = {
      ...formData,
      type: "document",
      date: new Date().toISOString().split("T")[0],
      status: "pending",
    };
    onSubmit(requestData);
    setFormData({
      name: "",
      documentType: "barangay-clearance",
      purpose: "",
      contact: "",
    });
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Request Barangay Documents</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.formGroup}>
          <label style={styles.label}>Full Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            style={styles.input}
            required
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Document Type</label>
          <select
            name="documentType"
            value={formData.documentType}
            onChange={handleChange}
            style={styles.select}
            required
          >
            {documentTypes.map((doc) => (
              <option key={doc.value} value={doc.value}>
                {doc.label}
              </option>
            ))}
          </select>
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Purpose</label>
          <textarea
            name="purpose"
            value={formData.purpose}
            onChange={handleChange}
            style={styles.textarea}
            required
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Contact Info</label>
          <input
            type="text"
            name="contact"
            value={formData.contact}
            onChange={handleChange}
            style={styles.input}
            required
          />
        </div>

        <button type="submit" style={styles.submitButton}>
          Submit Request
        </button>
      </form>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "600px",
    margin: "0 auto",
    padding: "20px",
    fontFamily: "sans-serif",
  },
  title: {
    textAlign: "center",
    marginBottom: "20px",
    color: "#333",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "15px",
  },
  formGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "5px",
  },
  label: {
    fontWeight: "600",
    fontSize: "14px",
  },
  input: {
    padding: "10px",
    border: "1px solid #ddd",
    borderRadius: "4px",
  },
  select: {
    padding: "10px",
    border: "1px solid #ddd",
    borderRadius: "4px",
    background: "white",
  },
  textarea: {
    padding: "10px",
    border: "1px solid #ddd",
    borderRadius: "4px",
    minHeight: "100px",
    resize: "vertical",
  },
  submitButton: {
    padding: "12px",
    background: "#4CAF50",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    fontSize: "16px",
    marginTop: "10px",
    ":hover": {
      background: "#45a049",
    },
  },
};

export default Requests;
