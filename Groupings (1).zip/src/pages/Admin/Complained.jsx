import React from "react";

export default function Complained({ complaints }) {
  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1 style={styles.title}>📋 Complaint Dashboard</h1>
        <div style={styles.stats}>
          <div style={styles.statCard}>
            <span style={styles.statNumber}>{complaints.length}</span>
            <span style={styles.statLabel}>Total</span>
          </div>
          <div style={styles.statCard}>
            <span style={styles.statNumber}>
              {complaints.filter((c) => c.status === "Pending").length}
            </span>
            <span style={styles.statLabel}>Pending</span>
          </div>
        </div>
      </div>

      <div style={styles.complaintsContainer}>
        {complaints.length === 0 ? (
          <div style={styles.emptyState}>
            <p style={styles.emptyText}>No complaints submitted yet</p>
          </div>
        ) : (
          complaints.map((complaint) => (
            <div
              key={complaint.id}
              style={{
                ...styles.complaintCard,
                borderLeft: `4px solid ${getUrgencyColor(complaint.urgency)}`,
              }}
            >
              <div style={styles.cardHeader}>
                <div>
                  <h3 style={styles.complaintType}>
                    {complaint.complaintType}
                  </h3>
                  <span style={styles.complaintDate}>{complaint.date}</span>
                </div>
                <span
                  style={{
                    ...styles.statusBadge,
                    backgroundColor: getStatusColor(complaint.status),
                  }}
                >
                  {complaint.status}
                </span>
              </div>

              <p style={styles.complaintDesc}>{complaint.description}</p>

              <div style={styles.cardFooter}>
                <span style={styles.urgencyTag}>
                  Urgency: <strong>{complaint.urgency}</strong>
                </span>
                <button style={styles.actionButton}>Mark as Resolved</button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// Helper functions
function getUrgencyColor(urgency) {
  const colors = {
    high: "#f56565",
    medium: "#ed8936",
    low: "#48bb78",
  };
  return colors[urgency] || "#a0aec0";
}

function getStatusColor(status) {
  const colors = {
    Pending: "#ecc94b",
    Resolved: "#48bb78",
    Rejected: "#f56565",
  };
  return colors[status] || "#a0aec0";
}

const styles = {
  container: {
    padding: "24px",
    maxWidth: "1200px",
    margin: "0 auto",
    fontFamily: "Segoe UI, Roboto, sans-serif",
  },
  header: {
    marginBottom: "32px",
  },
  title: {
    color: "#2d3748",
    fontSize: "28px",
    fontWeight: "600",
    marginBottom: "16px",
  },
  stats: {
    display: "flex",
    gap: "16px",
  },
  statCard: {
    backgroundColor: "white",
    borderRadius: "8px",
    padding: "16px 24px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  statNumber: {
    fontSize: "24px",
    fontWeight: "700",
    color: "#2d3748",
  },
  statLabel: {
    fontSize: "14px",
    color: "#718096",
  },
  complaintsContainer: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
  },
  complaintCard: {
    backgroundColor: "white",
    borderRadius: "8px",
    padding: "24px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
    transition: "transform 0.2s",
    ":hover": {
      transform: "translateY(-2px)",
    },
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: "16px",
  },
  complaintType: {
    margin: "0",
    color: "#2d3748",
    fontSize: "18px",
  },
  complaintDate: {
    color: "#718096",
    fontSize: "14px",
  },
  statusBadge: {
    padding: "4px 12px",
    borderRadius: "12px",
    fontSize: "14px",
    fontWeight: "600",
    color: "white",
  },
  complaintDesc: {
    color: "#4a5568",
    lineHeight: "1.6",
    marginBottom: "16px",
  },
  cardFooter: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  urgencyTag: {
    color: "#718096",
    fontSize: "14px",
  },
  actionButton: {
    padding: "8px 16px",
    borderRadius: "6px",
    backgroundColor: "#4299e1",
    color: "white",
    border: "none",
    fontSize: "14px",
    fontWeight: "600",
    cursor: "pointer",
    transition: "all 0.2s",
    ":hover": {
      backgroundColor: "#3182ce",
    },
  },
  emptyState: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "200px",
    backgroundColor: "white",
    borderRadius: "8px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
  },
  emptyText: {
    color: "#a0aec0",
    fontSize: "18px",
  },
};
