import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Requested = ({ isAdmin }) => {
  const navigate = useNavigate();
  const [requests, setRequests] = useState([]);
  const [filter, setFilter] = useState("all"); // 'all', 'documents', 'aid'
  const [loading, setLoading] = useState(true);

  // Mock data fetch - replace with actual API call
  useEffect(() => {
    const fetchRequests = async () => {
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 500));

        const mockData = [
          {
            id: 1,
            type: "documents",
            name: "Juan Dela Cruz",
            request: "Barangay Clearance",
            date: "2023-06-15",
            status: "pending",
            contact: "09123456789",
          },
          {
            id: 2,
            type: "aid",
            name: "Maria Santos",
            request: "Financial Assistance",
            date: "2023-06-14",
            status: "approved",
            contact: "maria@email.com",
          },
          {
            id: 3,
            type: "documents",
            name: "Pedro Reyes",
            request: "Business Permit",
            date: "2023-06-13",
            status: "rejected",
            contact: "09187654321",
          },
        ];

        setRequests(mockData);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching requests:", error);
        setLoading(false);
      }
    };

    fetchRequests();
  }, []);

  const handleStatusUpdate = (id, newStatus) => {
    setRequests((prevRequests) =>
      prevRequests.map((request) =>
        request.id === id ? { ...request, status: newStatus } : request
      )
    );
  };

  const filteredRequests =
    filter === "all" ? requests : requests.filter((req) => req.type === filter);

  if (!isAdmin) {
    navigate("/admin");
    return null;
  }

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>Manage Requests</h1>

      <div style={styles.filterContainer}>
        <button
          style={filter === "all" ? styles.activeFilter : styles.filterButton}
          onClick={() => setFilter("all")}
        >
          All Requests
        </button>
        <button
          style={
            filter === "documents" ? styles.activeFilter : styles.filterButton
          }
          onClick={() => setFilter("documents")}
        >
          Document Requests
        </button>
        <button
          style={filter === "aid" ? styles.activeFilter : styles.filterButton}
          onClick={() => setFilter("aid")}
        >
          Aid Requests
        </button>
      </div>

      {loading ? (
        <p>Loading requests...</p>
      ) : (
        <div style={styles.requestsContainer}>
          {filteredRequests.length === 0 ? (
            <p>No requests found</p>
          ) : (
            filteredRequests.map((request) => (
              <div key={request.id} style={styles.requestCard}>
                <div style={styles.requestHeader}>
                  <h3>{request.name}</h3>
                  <span
                    style={{
                      ...styles.statusBadge,
                      ...(request.status === "approved" ? styles.approved : {}),
                      ...(request.status === "rejected" ? styles.rejected : {}),
                    }}
                  >
                    {request.status}
                  </span>
                </div>

                <p>
                  <strong>Type:</strong>{" "}
                  {request.type === "documents" ? "Document" : "Aid"}
                </p>
                <p>
                  <strong>Request:</strong> {request.request}
                </p>
                <p>
                  <strong>Date:</strong> {request.date}
                </p>
                <p>
                  <strong>Contact:</strong> {request.contact}
                </p>

                <div style={styles.actionButtons}>
                  <button
                    style={styles.approveButton}
                    onClick={() => handleStatusUpdate(request.id, "approved")}
                  >
                    Approve
                  </button>
                  <button
                    style={styles.rejectButton}
                    onClick={() => handleStatusUpdate(request.id, "rejected")}
                  >
                    Reject
                  </button>
                  <button
                    style={styles.pendingButton}
                    onClick={() => handleStatusUpdate(request.id, "pending")}
                  >
                    Set Pending
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    padding: "20px",
    maxWidth: "1200px",
    margin: "0 auto",
    fontFamily: "sans-serif",
  },
  header: {
    marginBottom: "30px",
  },
  filterContainer: {
    display: "flex",
    gap: "10px",
    marginBottom: "20px",
  },
  filterButton: {
    padding: "8px 16px",
    border: "1px solid #ddd",
    borderRadius: "4px",
    background: "white",
    cursor: "pointer",
  },
  activeFilter: {
    padding: "8px 16px",
    border: "1px solid #4CAF50",
    borderRadius: "4px",
    background: "#4CAF50",
    color: "white",
    cursor: "pointer",
  },
  requestsContainer: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(350px, 1fr))",
    gap: "20px",
  },
  requestCard: {
    border: "1px solid #eee",
    borderRadius: "8px",
    padding: "20px",
    boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
  },
  requestHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "15px",
  },
  statusBadge: {
    padding: "4px 8px",
    borderRadius: "4px",
    background: "#ff9800",
    color: "white",
    fontSize: "14px",
  },
  approved: {
    background: "#4CAF50",
  },
  rejected: {
    background: "#f44336",
  },
  actionButtons: {
    display: "flex",
    gap: "10px",
    marginTop: "15px",
  },
  approveButton: {
    padding: "6px 12px",
    background: "#4CAF50",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
  rejectButton: {
    padding: "6px 12px",
    background: "#f44336",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
  pendingButton: {
    padding: "6px 12px",
    background: "#ff9800",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
};

export default Requested;
