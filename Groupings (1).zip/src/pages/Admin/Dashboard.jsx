import React from "react";
import { useNavigate } from "react-router-dom";

const Dashboard = ({ isAdmin }) => {
  const navigate = useNavigate();

  if (!isAdmin) {
    return (
      <div style={styles.deniedContainer}>
        <h2>Access Denied</h2>
        <p>You need administrator privileges</p>
        <button style={styles.button} onClick={() => navigate("/login")}>
          Go to login
        </button>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1>Admin Control Panel</h1>
        <button style={styles.logoutButton} onClick={() => navigate("/login")}>
          Logout
        </button>
      </div>

      <div style={styles.panelContainer}>
        <div style={styles.panel} onClick={() => navigate("/complaints")}>
          <h3>Complaints</h3>
          <p>View and manage complaints</p>
        </div>

        <div style={styles.panel} onClick={() => navigate("/requests")}>
          <h3>Requests</h3>
          <p>Manage user requests</p>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    padding: "20px",
    maxWidth: "1000px",
    margin: "0 auto",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "40px",
    borderBottom: "1px solid #eee",
    paddingBottom: "20px",
  },
  panelContainer: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
    gap: "20px",
  },
  panel: {
    border: "1px solid #eee",
    borderRadius: "8px",
    padding: "20px",
    cursor: "pointer",
    transition: "0.2s",
    ":hover": {
      transform: "translateY(-2px)",
      boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
    },
  },
  deniedContainer: {
    height: "100vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
  },
  button: {
    marginTop: "20px",
    padding: "10px 20px",
    background: "#000",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
  logoutButton: {
    padding: "8px 16px",
    background: "none",
    border: "1px solid #ddd",
    borderRadius: "4px",
    cursor: "pointer",
  },
};

export default Dashboard;
