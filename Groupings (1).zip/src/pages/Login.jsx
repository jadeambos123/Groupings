import React from "react";
import { useNavigate } from "react-router-dom";

const Login = ({ onLogin }) => {
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const { username, password } = e.target.elements; // Fixed typo: "elments" → "elements"

    if (onLogin(username.value, password.value)) {
      navigate("/admin/dashboard"); // Fixed path: "./Admin/Deshboard" → "/admin/dashboard"
    } else {
      alert("Invalid credentials. Use admin/admin123");
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.header}>Admin Login</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.formGroup}>
          <label style={styles.label}>
            Username
            <input
              name="username"
              type="text"
              placeholder="admin"
              required
              style={styles.input}
            />
          </label>
        </div>
        <div style={styles.formGroup}>
          <label style={styles.label}>
            Password
            <input
              name="password"
              type="password"
              placeholder="admin123"
              required
              style={styles.input}
            />
          </label>
        </div>
        <button type="submit" style={styles.button}>
          Login
        </button>
      </form>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "400px",
    margin: "2rem auto",
    padding: "2rem",
    backgroundColor: "#f8f9fa",
    borderRadius: "10px",
    boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
  },
  header: {
    color: "#2e7d32", // Fixed color code: #2zfd32 → #2e7d32
    textAlign: "center",
    marginBottom: "1.5rem",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "1.5rem",
  },
  formGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "0.5rem",
  },
  label: {
    fontWeight: "500",
    color: "#495057",
  },
  input: {
    padding: "0.75rem",
    border: "1px solid #ced4da",
    borderRadius: "6px",
    fontSize: "1rem",
  },
  button: {
    padding: "0.75rem",
    backgroundColor: "#2e7d32",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
  },
};

export default Login;
