import React, { useState } from "react";

const Complaints = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    name: "",
    contact: "",
    urgency: "medium",
    description: "",
    photo: null,
    photoPreview: "",
  });

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.size > 5 * 1024 * 1024) {
      alert("Please upload an image smaller than 5MB");
      return;
    }
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({
          ...prev,
          photo: file,
          photoPreview: reader.result,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const complaintData = {
      ...formData,
      id: Date.now(),
      date: new Date().toISOString(),
      status: "pending",
    };
    onSubmit(complaintData);
    // Reset form
    setFormData({
      name: "",
      contact: "",
      urgency: "medium",
      description: "",
      photo: null,
      photoPreview: "",
    });
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.header}>File a Complaint</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        {/* Personal Information */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Personal Information</h3>
          <div style={styles.formGroup}>
            <label style={styles.label}>Full Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              style={styles.input}
              required
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Contact Information</label>
            <input
              type="text"
              value={formData.contact}
              onChange={(e) =>
                setFormData({ ...formData, contact: e.target.value })
              }
              style={styles.input}
              required
            />
          </div>
        </div>

        {/* Urgency Level */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Urgency Level</h3>
          <div style={styles.radioGroup}>
            {[
              { value: "low", label: "Low", color: "#4CAF50" },
              { value: "medium", label: "Medium", color: "#FFC107" },
              { value: "high", label: "High", color: "#F44336" },
            ].map((option) => (
              <label key={option.value} style={styles.radioLabel}>
                <input
                  type="radio"
                  name="urgency"
                  value={option.value}
                  checked={formData.urgency === option.value}
                  onChange={() =>
                    setFormData({ ...formData, urgency: option.value })
                  }
                  style={{ ...styles.radioInput, accentColor: option.color }}
                />
                <span
                  style={{
                    ...styles.radioCustom,
                    borderColor: option.color,
                    backgroundColor:
                      formData.urgency === option.value
                        ? option.color
                        : "transparent",
                  }}
                />
                {option.label}
              </label>
            ))}
          </div>
        </div>

        {/* Complaint Details */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Complaint Details</h3>
          <div style={styles.formGroup}>
            <label style={styles.label}>Description</label>
            <textarea
              value={formData.description}
              onChange={(e) =>
                setFormData({ ...formData, description: e.target.value })
              }
              style={styles.textarea}
              placeholder="Please describe your complaint in detail..."
              required
            />
          </div>
        </div>

        {/* Evidence Upload */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Attach Evidence (Optional)</h3>
          <div style={styles.uploadArea}>
            <label style={styles.uploadLabel}>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                style={styles.fileInput}
              />
              <div style={styles.uploadBox}>
                {formData.photoPreview ? (
                  <img
                    src={formData.photoPreview}
                    alt="Preview"
                    style={styles.previewImage}
                  />
                ) : (
                  <>
                    <span style={styles.uploadIcon}>📁</span>
                    <span>Click to upload image</span>
                    <span style={styles.uploadHint}>(Max 5MB)</span>
                  </>
                )}
              </div>
            </label>
            {formData.photoPreview && (
              <button
                type="button"
                onClick={() =>
                  setFormData({ ...formData, photo: null, photoPreview: "" })
                }
                style={styles.removeButton}
              >
                Remove Image
              </button>
            )}
          </div>
        </div>

        <button type="submit" style={styles.submitButton}>
          Submit Complaint
        </button>
      </form>
    </div>
  );
};

// Modern Styles
const styles = {
  container: {
    maxWidth: "800px",
    margin: "2rem auto",
    padding: "2rem",
    backgroundColor: "#ffffff",
    borderRadius: "12px",
    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)",
    fontFamily: "'Segoe UI', Roboto, sans-serif",
  },
  header: {
    color: "#2e7d32",
    textAlign: "center",
    marginBottom: "2rem",
    fontSize: "1.8rem",
    fontWeight: "600",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "2rem",
  },
  section: {
    backgroundColor: "#f8f9fa",
    padding: "1.5rem",
    borderRadius: "10px",
    boxShadow: "inset 0 1px 3px rgba(0,0,0,0.05)",
  },
  sectionTitle: {
    color: "#495057",
    marginTop: "0",
    marginBottom: "1rem",
    fontSize: "1.2rem",
    fontWeight: "500",
  },
  formGroup: {
    marginBottom: "1.2rem",
  },
  label: {
    display: "block",
    marginBottom: "0.5rem",
    color: "#495057",
    fontWeight: "500",
    fontSize: "0.95rem",
  },
  input: {
    width: "100%",
    padding: "0.8rem",
    border: "1px solid #ced4da",
    borderRadius: "8px",
    fontSize: "1rem",
    transition: "border-color 0.2s",
    ":focus": {
      outline: "none",
      borderColor: "#2e7d32",
      boxShadow: "0 0 0 3px rgba(46, 125, 50, 0.2)",
    },
  },
  textarea: {
    width: "100%",
    minHeight: "120px",
    padding: "0.8rem",
    border: "1px solid #ced4da",
    borderRadius: "8px",
    fontSize: "1rem",
    resize: "vertical",
    transition: "border-color 0.2s",
    ":focus": {
      outline: "none",
      borderColor: "#2e7d32",
      boxShadow: "0 0 0 3px rgba(46, 125, 50, 0.2)",
    },
  },
  radioGroup: {
    display: "flex",
    gap: "1.5rem",
    marginTop: "0.5rem",
  },
  radioLabel: {
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
    cursor: "pointer",
    fontSize: "0.95rem",
    color: "#495057",
  },
  radioInput: {
    display: "none",
  },
  radioCustom: {
    width: "18px",
    height: "18px",
    borderRadius: "50%",
    border: "2px solid",
    display: "inline-block",
    transition: "all 0.2s",
  },
  uploadArea: {
    textAlign: "center",
  },
  uploadLabel: {
    cursor: "pointer",
  },
  uploadBox: {
    border: "2px dashed #ced4da",
    borderRadius: "8px",
    padding: "2rem",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "0.5rem",
    transition: "all 0.2s",
    ":hover": {
      borderColor: "#2e7d32",
      backgroundColor: "rgba(46, 125, 50, 0.05)",
    },
  },
  uploadIcon: {
    fontSize: "2rem",
    marginBottom: "0.5rem",
  },
  uploadHint: {
    fontSize: "0.8rem",
    color: "#6c757d",
  },
  previewImage: {
    maxWidth: "100%",
    maxHeight: "200px",
    borderRadius: "6px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
  },
  removeButton: {
    marginTop: "1rem",
    padding: "0.5rem 1rem",
    backgroundColor: "#f8f9fa",
    color: "#dc3545",
    border: "1px solid #dc3545",
    borderRadius: "6px",
    cursor: "pointer",
    transition: "all 0.2s",
    ":hover": {
      backgroundColor: "#dc3545",
      color: "white",
    },
  },
  submitButton: {
    padding: "1rem",
    backgroundColor: "#2e7d32",
    color: "white",
    border: "none",
    borderRadius: "8px",
    fontSize: "1rem",
    fontWeight: "500",
    cursor: "pointer",
    transition: "all 0.2s",
    ":hover": {
      backgroundColor: "#1e5a23",
      transform: "translateY(-2px)",
      boxShadow: "0 4px 12px rgba(46, 125, 50, 0.3)",
    },
  },
};

export default Complaints;
