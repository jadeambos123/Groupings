import React from "react";
import { useNavigate } from "react-router-dom";
import requestIcon from "../assets/req.png";
import complaintIcon from "../assets/6553470.png";
import aidIcon from "../assets/1321724.png";

function Home() {
  const navigate = useNavigate();
  const isAdmin = localStorage.getItem("isAdmin") === "true";

  React.useEffect(() => {
    if (isAdmin) navigate("/admin");
  }, [isAdmin, navigate]);

  if (isAdmin) return null;

  const services = [
    {
      name: "Request Documents",
      icon: requestIcon,
      action: () => navigate("/Requests"),
    },
    {
      name: "Complaints",
      icon: complaintIcon,
      action: () => navigate("/Complaints"),
    },
    {
      name: "Request Aid",
      icon: aidIcon,
      action: () => navigate("/Aid"),
    },
  ];

  const announcements = [
    "Curfew updated to 10 PM starting April 15",
    "Free medical check-up every Thursday",
    "Garbage collection moved to Mondays/Thursdays",
  ];

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <h1 style={styles.title}>Barangay Services</h1>
        <div style={styles.locationSelector}>
          <select style={styles.select} defaultValue="Consolacion">
            <option value="Macasandige">Drug-Friage</option>
            <option value="Consolacion">Consolacion</option>
            <option value="Bulua">Bullus</option>
            <option value="Balulang">Mechanic</option>
          </select>
        </div>
      </div>

      {/* Services Grid */}
      <div style={styles.grid}>
        {services.map((service, index) => (
          <div key={index} style={styles.card} onClick={service.action}>
            <img src={service.icon} alt={service.name} style={styles.icon} />
            <h3 style={styles.cardTitle}>{service.name}</h3>
          </div>
        ))}
      </div>

      {/* Login Card */}
      <div style={styles.loginCard} onClick={() => navigate("/login")}>
        <div style={styles.loginContent}>
          <span style={styles.loginIcon}>→</span>
          <h3 style={styles.loginText}>Barangay Login</h3>
        </div>
      </div>

      {/* Announcements */}
      <div style={styles.announcements}>
        <h3 style={styles.sectionTitle}>Announcements</h3>
        <ul style={styles.list}>
          {announcements.map((item, index) => (
            <li key={index} style={styles.listItem}>
              <div style={styles.bullet}></div>
              <p style={styles.announcementText}>{item}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: "800px",
    margin: "0 auto",
    padding: "20px",
    fontFamily: "'Roboto', Arial, sans-serif",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "40px",
  },
  title: {
    fontSize: "24px",
    color: "#202124",
    fontWeight: "400",
    margin: "0",
  },
  locationSelector: {
    position: "relative",
  },
  select: {
    padding: "8px 32px 8px 12px",
    borderRadius: "4px",
    border: "1px solid #dadce0",
    appearance: "none",
    fontSize: "14px",
    background: `url("data:image/svg+xml;utf8,<svg fill='%23333' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/><path d='M0 0h24v24H0z' fill='none'/></svg>") no-repeat right 8px center/16px 16px`,
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
    gap: "20px",
    marginBottom: "30px",
  },
  card: {
    border: "1px solid #dadce0",
    borderRadius: "8px",
    padding: "24px",
    textAlign: "center",
    cursor: "pointer",
    transition: "box-shadow 0.2s",
    ":hover": {
      boxShadow: "0 1px 6px rgba(0,0,0,0.1)",
    },
  },
  icon: {
    width: "48px",
    height: "48px",
    marginBottom: "16px",
  },
  cardTitle: {
    fontSize: "16px",
    color: "#202124",
    margin: "0",
    fontWeight: "500",
  },
  loginCard: {
    border: "1px solid #dadce0",
    borderRadius: "8px",
    padding: "16px",
    marginBottom: "30px",
    cursor: "pointer",
    transition: "box-shadow 0.2s",
    ":hover": {
      boxShadow: "0 1px 6px rgba(0,0,0,0.1)",
    },
  },
  loginContent: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "12px",
  },
  loginIcon: {
    color: "#5f6368",
    fontSize: "20px",
  },
  loginText: {
    fontSize: "14px",
    color: "#5f6368",
    margin: "0",
    fontWeight: "500",
  },
  announcements: {
    borderTop: "1px solid #dadce0",
    paddingTop: "20px",
  },
  sectionTitle: {
    fontSize: "14px",
    color: "#5f6368",
    margin: "0 0 16px 0",
    fontWeight: "500",
    textTransform: "uppercase",
  },
  list: {
    listStyle: "none",
    padding: "0",
    margin: "0",
  },
  listItem: {
    display: "flex",
    gap: "12px",
    padding: "8px 0",
    alignItems: "flex-start",
  },
  bullet: {
    width: "8px",
    height: "8px",
    backgroundColor: "#1a73e8",
    borderRadius: "50%",
    marginTop: "6px",
    flexShrink: "0",
  },
  announcementText: {
    fontSize: "14px",
    color: "#202124",
    margin: "0",
  },
};

export default Home;
