import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  Link,
} from "react-router-dom";

// Pages
import Home from "./pages/Home";
import Login from "./pages/Login";
import Requests from "./pages/Requests";
import Aid from "./pages/Aid";
import Complaints from "./pages/Complaints";

// Admin Pages
import Dashboard from "./pages/Admin/Dashboard";
import Requested from "./pages/Admin/Requested";
import Complained from "./pages/Admin/Complained";

const App = () => {
  const [isAdmin, setIsAdmin] = useState(false);

  // Sync auth state on app load
  useEffect(() => {
    const savedAuth = localStorage.getItem("isAdmin") === "true";
    setIsAdmin(savedAuth);
  }, []);

  // Login handler
  const handleLogin = (username, password) => {
    if (username === "admin" && password === "admin123") {
      localStorage.setItem("isAdmin", "true");
      setIsAdmin(true);
      return true;
    }
    return false;
  };

  // Logout handler
  const handleLogout = () => {
    localStorage.removeItem("isAdmin");
    setIsAdmin(false);
    window.location.href = "/"; // Full refresh to clear state
  };

  return (
    <Router>
      {/* Control Bar */}
      <div
        style={{
          backgroundColor: "#2e7d32",
          padding: "1rem",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        {/* BARANGAY link - Always clickable */}
        <Link
          to="/"
          style={{
            color: "white",
            textDecoration: "none",
            fontSize: "1.2rem",
            fontWeight: "bold",
            cursor: "pointer", // Ensure clickable
          }}
        >
          BARANGAY
        </Link>

        {/* Admin/Logout link */}
        {isAdmin ? (
          <button
            onClick={handleLogout}
            style={{
              background: "none",
              border: "1px solid white",
              color: "white",
              padding: "0.5rem 1rem",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            Logout
          </button>
        ) : (
          <Link
            to="/login"
            style={{
              color: "white",
              textDecoration: "none",
              cursor: "pointer", // Ensure clickable
            }}
          >
            ADMIN LOGIN
          </Link>
        )}
      </div>

      {/* Routes */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login onLogin={handleLogin} />} />
        <Route path="/requests" element={<Requests />} />
        <Route path="/aid" element={<Aid />} />
        <Route path="/complaints" element={<Complaints />} />

        <Route
          path="/admin/dashboard"
          element={isAdmin ? <Dashboard /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/admin/requested"
          element={isAdmin ? <Requested /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/admin/complained"
          element={isAdmin ? <Complained /> : <Navigate to="/login" replace />}
        />
      </Routes>
    </Router>
  );
};

export default App;
