export default function Complaints() {
  return <h2>File a Complaint</h2>;
}
