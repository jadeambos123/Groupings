export default function Requests() {
  return <h2>Request a Document</h2>;
}
